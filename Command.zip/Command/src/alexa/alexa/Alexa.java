package alexa.alexa;

import java.util.LinkedList;
import java.util.Queue;

import alexa.Command;

public class Alexa {
	private Queue<Command> commands;
	
	public Alexa() {
		this.commands = new LinkedList<Command>();
	}
	
	public void addCommand(Command command) {
		commands.add(command);
	}

	public void sendRequest(String request) {
		System.out.println(request);
		if (commands.peek() != null) {
			commands.poll().execute();
		}
	}
}
