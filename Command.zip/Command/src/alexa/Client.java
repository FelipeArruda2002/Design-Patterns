package alexa;

import alexa.alexa.Alexa;
import alexa.lights.PhillipsHueLight;
import alexa.lights.XiaomiLight;

public class Client {

	public static void main(String[] args) {
		Alexa alexa = new Alexa();
		alexa.addCommand(new TurnOnCommand(new PhillipsHueLight()));
		alexa.addCommand(new TurnOffCommand(new XiaomiLight()));
		
		alexa.sendRequest("Turnning on the Living room light");
		alexa.sendRequest("Turnning off the Kitchen light");
		
	}
}
