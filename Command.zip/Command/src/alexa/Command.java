package alexa;

public interface Command {
	
	void execute();

}
