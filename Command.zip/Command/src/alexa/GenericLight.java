package alexa;

public interface GenericLight {
	
	void turnOn();
	void turnOff();

}
